package com.company.wages.calculation.system.service;

import com.company.wages.calculation.system.domain.Employee;

import static com.company.wages.calculation.system.constant.SalaryEmpWageConstant.FIXED_WAGES;
import static com.company.wages.calculation.system.util.EmpWagesUtil.birthdayWelfareUtilDate;

/**
 *
 * 计算固定工资的员工工资
 * @author hy
 */
public class WageSalaryCalculationServiceImpl implements WageCalculationService {

    /**
     *  固定工资人员计算
     * @param month 工资月份
     * @param employee  固定工资人员
     * @return 计算所得工资
     */
    @Override
    public double employeeTypeWageCalculation(Integer month, Employee employee) {
        return birthdayWelfareUtilDate(month, employee.getBirthday()) + FIXED_WAGES;
    }
}
