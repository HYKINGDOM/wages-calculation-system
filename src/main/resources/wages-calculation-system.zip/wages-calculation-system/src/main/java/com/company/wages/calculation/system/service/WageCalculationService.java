package com.company.wages.calculation.system.service;

import com.company.wages.calculation.system.domain.Employee;

/**
 * 工资计算接口
 *
 * @author hy
 */
public interface WageCalculationService {

    /**
     * 根据不同胡员工类型计算员工薪资
     *
     * @param month        工资月份
     * @param employeeType 员工数据
     * @return 返回工资
     */
    double employeeTypeWageCalculation(Integer month, Employee employeeType);
}
