package com.company.wages.calculation.system.util;

import java.util.Calendar;
import java.util.Date;

/**
 * 员工薪资计算工具类
 *
 * @author hy
 */
public class EmpWagesUtil {

    /**
     * 计算员工在数据中的生日福利
     *
     * @param month 工资月份
     * @param date  员工生日
     * @return 如果生日和月份相匹配返回100生日福利反之则返回0
     */
    public static double birthdayWelfareUtilDate(Integer month, Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int currentMonth = cal.get(Calendar.MONTH) + 1;
        if (currentMonth == month) {
            return 100;
        }
        return 0;
    }

}
