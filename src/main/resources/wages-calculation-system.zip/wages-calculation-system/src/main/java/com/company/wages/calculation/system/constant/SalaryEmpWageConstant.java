package com.company.wages.calculation.system.constant;

/**
 * 固定工资员工工资常量
 * @author hy
 */
public class SalaryEmpWageConstant {

    /**
     * 固定工资员工每月固定工资
     */
    public final static double FIXED_WAGES = 6000.00;
}
