package com.company.wages.calculation.system.service;

import com.company.wages.calculation.system.domain.Employee;

import static com.company.wages.calculation.system.constant.HourEmpWageConstant.*;
import static com.company.wages.calculation.system.util.EmpWagesUtil.birthdayWelfareUtilDate;

/**
 * 小时工工资计算
 *
 * @author hy
 */
public class WageHourCalculationServiceImpl implements WageCalculationService {
    @Override
    public double employeeTypeWageCalculation(Integer month, Employee employee) {
        double amount = birthdayWelfareUtilDate(month, employee.getBirthday());
        double workingHours = employee.getWorkingHours();
        double exceedingTime = workingHours - FIXED_HOURLY_WAGE;
        if (exceedingTime > 0) {
            amount = FIXED_HOURLY_WAGE * HOURLY_WAGE + exceedingTime * (HOURLY_WAGE * EXCEED_HOURLY_WAGE);
        } else if (exceedingTime <= 0) {
            amount = workingHours * HOURLY_WAGE;
        }
        return amount;
    }
}
