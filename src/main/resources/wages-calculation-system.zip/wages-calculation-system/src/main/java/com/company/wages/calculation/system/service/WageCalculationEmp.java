package com.company.wages.calculation.system.service;

import com.company.wages.calculation.system.domain.Employee;

/**
 *
 * 工资生成方案
 * @author hy
 */
public class WageCalculationEmp {

    private WageCalculationService wageCalculationService;

    public WageCalculationEmp(WageCalculationService wageCalculationService) {
        this.wageCalculationService = wageCalculationService;
    }

    public double execute(Integer month, Employee employeeType) {
        return wageCalculationService.employeeTypeWageCalculation(month, employeeType);
    }
}
