package com.company.wages.calculation.system;

import com.company.wages.calculation.system.domain.Employee;
import com.company.wages.calculation.system.domain.EmployeeTotal;
import com.company.wages.calculation.system.service.WageHourCalculationServiceImpl;
import com.company.wages.calculation.system.service.WageSalaryCalculationServiceImpl;
import com.company.wages.calculation.system.service.WageSaleCalculationServiceImpl;
import com.company.wages.calculation.system.service.WageCalculationEmp;
import com.company.wages.calculation.system.util.EmployeeType;
import com.company.wages.calculation.system.util.ReaderXmlFileUtil;

import java.util.List;

import static com.company.wages.calculation.system.util.CommonUtil.doubleKeepTwoDecimalPlaces;

/**
 * 主方法
 *
 * @author hy
 */
public class CalculationMain {

    public static void main(String[] args) {
        ReaderXmlFileUtil readerXmlFileUtil = new ReaderXmlFileUtil();
        List<EmployeeTotal> listMap = readerXmlFileUtil.readerXmlFile();
        WageCalculationEmp wageCalculationEmp = null;
        double amount = 0;
        for (EmployeeTotal employeeTotal : listMap) {
            List<Employee> employeeList = employeeTotal.getEmployeeList();
            for (Employee employee : employeeList) {
                String type = employee.getType().trim();
                if (EmployeeType.sale.toString().equals(type)) {
                    wageCalculationEmp = new WageCalculationEmp(new WageSaleCalculationServiceImpl());
                } else if (EmployeeType.salary.toString().equals(type)) {
                    wageCalculationEmp = new WageCalculationEmp(new WageSalaryCalculationServiceImpl());
                } else if (EmployeeType.hour.toString().equals(type)) {
                    wageCalculationEmp = new WageCalculationEmp(new WageHourCalculationServiceImpl());
                }
                if (wageCalculationEmp != null) {
                    amount += wageCalculationEmp.execute(employeeTotal.getMonth(), employee);
                }
            }
        }
        System.out.println("9月和10月份，公司应支付员工工资总额为:" + doubleKeepTwoDecimalPlaces(amount));
    }
}
